#include "Shell_h.h"
#include <stdarg.h>
#include <strsafe.h>


void
DebugPrintf(
    LPCTSTR Format,
    ...
    )
{
    va_list args;
    HRESULT hr;
    TCHAR buf[0x800];

    va_start(args, Format);
    hr = StringCbVPrintf(buf, sizeof(buf), Format, args);

    if (SUCCEEDED(hr))
    {
        OutputDebugString(buf);
    }
}


unsigned long __RPC_USER
PDATABLOCK_UserSize(
    unsigned long __RPC_FAR *pFlags,
    unsigned long StartingSize,
    PDATABLOCK __RPC_FAR *pUserObject
    )
{
#ifdef _DEBUG
    DebugPrintf(
        L"PDATABLOCK_UserSize(0x%x, %d, 0x%p)\n", 
        *pFlags, 
        StartingSize, 
        *pUserObject);
#endif

    if (USER_CALL_CTXT_MASK(*pFlags) == MSHCTX_INPROC)
    {
        // Simply transmit the pointer in case of an in-proc call
        return StartingSize + sizeof(*pUserObject);
    }
    else
    {
        if (*pUserObject && ((*pUserObject)->cbSize >= sizeof(wireDATABLOCK_HEADER)))
        {
            // Valid object
            return StartingSize + (*pUserObject)->cbSize;
        }
        else
        {
            // Null or invalid pointer
            return StartingSize + sizeof((*pUserObject)->cbSize);
        }
    }
}


unsigned char __RPC_FAR * __RPC_USER
PDATABLOCK_UserMarshal(
    unsigned long __RPC_FAR * pFlags,
    unsigned char __RPC_FAR * pBuffer,
    PDATABLOCK __RPC_FAR * pUserObject
    )
{
#ifdef _DEBUG
    DebugPrintf(
        L"PDATABLOCK_UserMarshal(0x%x, 0x%p, 0x%p)\n", 
        *pFlags, 
        pBuffer, 
        *pUserObject);
#endif

    if (USER_CALL_CTXT_MASK(*pFlags) == MSHCTX_INPROC)
    {
        // Simply transmit the pointer in case of an in-proc call
        *((PDATABLOCK*)pBuffer) = *pUserObject;

        return pBuffer + sizeof(*pUserObject);
    }
    else
    {
        DWORD cbSize = PDATABLOCK_UserSize(pFlags, 0, pUserObject);

        if (cbSize < sizeof(wireDATABLOCK_HEADER))
        {
            // Valid object
            memset(pBuffer, 0, cbSize);
        }
        else
        {
            // Null or invalid pointer
            memcpy(pBuffer, *pUserObject, cbSize);
        }

        return pBuffer + cbSize;
    }
}


unsigned char __RPC_FAR * __RPC_USER
PDATABLOCK_UserUnmarshal(
    unsigned long __RPC_FAR * pFlags,
    unsigned char __RPC_FAR * pBuffer,
    PDATABLOCK __RPC_FAR * pMyObj
    )
{
#ifdef _DEBUG
    DebugPrintf(
        L"PDATABLOCK_UserUnmarshal(0x%x, 0x%p, 0x%p)\n", 
        *pFlags, 
        pBuffer, 
        *pMyObj);
#endif

    if (USER_CALL_CTXT_MASK(*pFlags) == MSHCTX_INPROC)
    {
        // Receive the pointer in case of an in-proc call
        *pMyObj = *((PDATABLOCK*)pBuffer);

        return pBuffer + sizeof(*pMyObj);
    }
    else
    {
        DWORD cbSize = ((wirePDATABLOCK_HEADER)pBuffer)->cbSize;

        if (cbSize >= sizeof(wireDATABLOCK_HEADER))
        {
            // Valid object
            *pMyObj = (PDATABLOCK)LocalAlloc(LMEM_FIXED, cbSize);

            if (*pMyObj)
            {
#ifdef _DEBUG
                DebugPrintf(
                    L"PDATABLOCK_UserMarshal: LocalAlloc(): 0x%p\n", 
                    *pMyObj);
#endif

                memcpy(*pMyObj, pBuffer, cbSize);
            }
        }
        else
        {
            // Null or invalid pointer
            *pMyObj = NULL;
        }

        return pBuffer + cbSize;
    }
}


void __RPC_USER
PDATABLOCK_UserFree(
    unsigned long __RPC_FAR * pFlags,
    PDATABLOCK __RPC_FAR * pMyObj
    )
{
#ifdef _DEBUG
    DebugPrintf(
        L"PDATABLOCK_UserFree(0x%x, 0x%p)\n", 
        *pFlags, 
        *pMyObj);
#endif

    // LocalAlloc is not called during an in-proc call
    if (*pMyObj && !(USER_CALL_CTXT_MASK(*pFlags) == MSHCTX_INPROC))
    {
        LocalFree((HLOCAL)(*pMyObj));
        *pMyObj = NULL;
    }
}
