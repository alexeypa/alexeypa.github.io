/**
    Copyright (c) 2006 Alexey Pakhunov <alexeypa@gmail.com>
*/

#include "Shell.h"
#include <stdarg.h>
#include <strsafe.h>
#include <shlobj.h>
#include <stddef.h>
#include <assert.h>


#define ALIGNED_LENGTH(_Len, _Align)    (((_Len) + (_Align)) & ~(_Align))
#define ALIGNED_POINTER(_Ptr, _Align)   ((LPVOID)ALIGNED_LENGTH((ULONG_PTR)(_Ptr), _Align))
#define ALIGN_LENGTH(_Len, _Align)      _Len = ALIGNED_LENGTH(_Len, _Align)
#define ALIGN_POINTER(_Ptr, _Align)     _Ptr = ALIGNED_POINTER(_Ptr, _Align)


void
DebugPrintf(
    LPCWSTR Format,
    ...
    )
{
    va_list args;
    HRESULT hr;
    WCHAR buf[0x800];

    va_start(args, Format);
    hr = StringCbVPrintfW(buf, sizeof(buf), Format, args);

    if (SUCCEEDED(hr))
    {
        OutputDebugStringW(buf);
    }
}


unsigned long __RPC_USER
PDATABLOCK_UserSize(
    unsigned long __RPC_FAR *pFlags,
    unsigned long StartingSize,
    PDATABLOCK __RPC_FAR *pUserObject
    )
{
    unsigned long size = StartingSize;

#if DBG
    DebugPrintf(
        L"PDATABLOCK_UserSize(0x%x, %d, 0x%p)\n",
        *pFlags,
        StartingSize,
        *pUserObject);
#endif

    ALIGN_LENGTH(size, 3);

    size += sizeof(DWORD);

    if (*pUserObject)
    {
        if ((*pUserObject)->cbSize < sizeof(DWORD))
        {
            RaiseException(RPC_X_BAD_STUB_DATA, 0, 0, NULL);
            return size;
        }

        if (USER_CALL_CTXT_MASK(*pFlags) == MSHCTX_INPROC)
        {
            size += sizeof(*pUserObject);
        }
        else
        {
            size += (*pUserObject)->cbSize - sizeof(DWORD);
        }
    }

#if DBG
    DebugPrintf(
        L"PDATABLOCK_UserSize: wire size %d\n",
        size - StartingSize);
#endif

    return size;
}


unsigned char __RPC_FAR * __RPC_USER
PDATABLOCK_UserMarshal(
    unsigned long __RPC_FAR * pFlags,
    unsigned char __RPC_FAR * pBuffer,
    PDATABLOCK __RPC_FAR * pUserObject
    )
{
    wirePDATABLOCK pWire;

#if DBG
    DebugPrintf(
        L"PDATABLOCK_UserMarshal(0x%x, 0x%p, 0x%p)\n",
        *pFlags,
        pBuffer,
        *pUserObject);
#endif

    ALIGN_POINTER(pBuffer, 3);

    pWire = (wirePDATABLOCK)pBuffer;

    if (*pUserObject)
    {
        if ((*pUserObject)->cbSize < sizeof(DWORD))
        {
            RaiseException(RPC_X_BAD_STUB_DATA, 0, 0, NULL);
            return pBuffer;
        }

        if (USER_CALL_CTXT_MASK(*pFlags) == MSHCTX_INPROC)
        {
            pWire->cbSize = sizeof(*pUserObject);

            memcpy(pWire->Data, pUserObject, pWire->cbSize);
        }
        else
        {
            pWire->cbSize = (*pUserObject)->cbSize - sizeof(DWORD);

            memcpy(pWire->Data, (*pUserObject)->Data, pWire->cbSize);
        }
    }
    else
    {
        pWire->cbSize = 0;
    }

    pBuffer += sizeof(DWORD) + pWire->cbSize;

    return pBuffer;
}


unsigned char __RPC_FAR * __RPC_USER
PDATABLOCK_UserUnmarshal(
    unsigned long __RPC_FAR * pFlags,
    unsigned char __RPC_FAR * pBuffer,
    PDATABLOCK __RPC_FAR * pMyObj
    )
{
    NDR_USER_MARSHAL_INFO info;
    RPC_STATUS status;
    unsigned char * pBufferEnd;

    DWORD cbSize;
    wirePDATABLOCK pWire;

#if DBG
    DebugPrintf(
        L"PDATABLOCK_UserUnmarshal(0x%x, 0x%p, 0x%p)\n",
        *pFlags,
        pBuffer,
        *pMyObj);
#endif


    *pMyObj = NULL;


    //
    // Get input buffer bounds
    //

    status = NdrGetUserMarshalInfo(pFlags, 1, &info);
    if (status != RPC_S_OK)
    {
        RaiseException(status, 0, 0, NULL);
        return pBuffer;
    }

    pBufferEnd = (unsigned char *)info.Level1.Buffer + info.Level1.BufferSize;


    //
    // Align the pointer
    //

    ALIGN_POINTER(pBuffer, 3);

    if (pBuffer + sizeof(DWORD) >= pBufferEnd)
    {
        RaiseException(RPC_X_BAD_STUB_DATA, 0, 0, NULL);
        return pBuffer;
    }


    //
    // Get size of data
    //

    pWire = (wirePDATABLOCK)pBuffer;
    cbSize = pWire->cbSize;

    pBuffer += sizeof(DWORD);


    //
    // Get data
    //

    if (cbSize > 0)
    {
        if ((ptrdiff_t)cbSize > pBufferEnd - pBuffer)
        {
            RaiseException(RPC_X_BAD_STUB_DATA, 0, 0, NULL);
            return pBuffer;
        }

        if (USER_CALL_CTXT_MASK(*pFlags) == MSHCTX_INPROC)
        {
            if (cbSize == sizeof(*pMyObj))
            {
                memcpy(pMyObj, pWire->Data, sizeof(*pMyObj));
            }
            else
            {
                RaiseException(RPC_X_BAD_STUB_DATA, 0, 0, NULL);
                return pBuffer;
            }

        }
        else
        {
            //
            // Allocate buffer of required size
            //

            *pMyObj = (PDATABLOCK)LocalAlloc(LMEM_FIXED, sizeof(DWORD) + cbSize);

            if (*pMyObj)
            {
#if DBG
                DebugPrintf(
                    L"PDATABLOCK_UserUnmarshal: LocalAlloc(%d): 0x%p\n",
                    sizeof(DWORD) + pWire->cbSize,
                    *pMyObj);
#endif

                memcpy((*pMyObj)->Data, pWire->Data, cbSize);
                (*pMyObj)->cbSize = sizeof(DWORD) + cbSize;
            }
            else
            {
#if DBG
                DebugPrintf(
                    L"PDATABLOCK_UserUnmarshal: LocalAlloc(%d) failed\n",
                    sizeof(DWORD) + cbSize);
#endif
            }
        }

        pBuffer += cbSize;
    }
    else
    {
        *pMyObj = NULL;
    }

    return pBuffer;
}


void __RPC_USER
PDATABLOCK_UserFree(
    unsigned long __RPC_FAR * pFlags,
    PDATABLOCK __RPC_FAR * pMyObj
    )
{
#if DBG
    DebugPrintf(
        L"PDATABLOCK_UserFree(0x%x, 0x%p)\n",
        *pFlags,
        *pMyObj);
#endif

    // LocalAlloc is not called during an in-proc call
    if (*pMyObj && !(USER_CALL_CTXT_MASK(*pFlags) == MSHCTX_INPROC))
    {
        LocalFree((HLOCAL)(*pMyObj));
    }

    *pMyObj = NULL;
}



#ifdef _WIN64

unsigned long __RPC_USER
PDATABLOCK_UserSize64(
    unsigned long __RPC_FAR *pFlags,
    unsigned long StartingSize,
    PDATABLOCK __RPC_FAR *pUserObject
    )
{
    return PDATABLOCK_UserSize(pFlags, StartingSize, pUserObject);
}


unsigned char __RPC_FAR * __RPC_USER
PDATABLOCK_UserMarshal64(
    unsigned long __RPC_FAR * pFlags,
    unsigned char __RPC_FAR * pBuffer,
    PDATABLOCK __RPC_FAR * pUserObject
    )
{
    return PDATABLOCK_UserMarshal(pFlags, pBuffer, pUserObject);
}


unsigned char __RPC_FAR * __RPC_USER
PDATABLOCK_UserUnmarshal64(
    unsigned long __RPC_FAR * pFlags,
    unsigned char __RPC_FAR * pBuffer,
    PDATABLOCK __RPC_FAR * pMyObj
    )
{
    return PDATABLOCK_UserUnmarshal(pFlags, pBuffer, pMyObj);
}


void __RPC_USER
PDATABLOCK_UserFree64(
    unsigned long __RPC_FAR * pFlags,
    PDATABLOCK __RPC_FAR * pMyObj
    )
{
    PDATABLOCK_UserFree(pFlags, pMyObj);
}

#endif
