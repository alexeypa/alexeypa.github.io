// ShortCut.h

#pragma once

#include <Shlobj.h>

using namespace System;
using namespace System::Runtime::InteropServices;
using namespace System::Drawing;


namespace ShellLib
{
    #undef SW_HIDE
    #undef SW_SHOWNORMAL
    #undef SW_NORMAL
    #undef SW_SHOWMINIMIZED
    #undef SW_SHOWMAXIMIZED
    #undef SW_MAXIMIZE
    #undef SW_SHOWNOACTIVATE
    #undef SW_SHOW
    #undef SW_MINIMIZE
    #undef SW_SHOWMINNOACTIVE
    #undef SW_SHOWNA
    #undef SW_RESTORE
    #undef SW_SHOWDEFAULT
    #undef SW_MAX

    // SH_XXX flags
    public enum EShowWindowFlags
    {
        SW_HIDE = 0,
        SW_SHOWNORMAL = 1,
        SW_NORMAL = 1,
        SW_SHOWMINIMIZED = 2,
        SW_SHOWMAXIMIZED = 3,
        SW_MAXIMIZE = 3,
        SW_SHOWNOACTIVATE = 4,
        SW_SHOW = 5,
        SW_MINIMIZE = 6,
        SW_SHOWMINNOACTIVE = 7,
        SW_SHOWNA = 8,
        SW_RESTORE = 9,
        SW_SHOWDEFAULT = 10,
        SW_MAX = 10
    };

    public enum EGetPathFlags
    {
        SLGP_SHORTPATH          = 1,
        SLGP_UNCPRIORITY        = 2,
        SLGP_RAWPATH            = 4,
        SLGP_RELATIVEPRIORITY   = 8
    };

    public enum EShellLinkResolveFlags
    {
        /// <summary>
        /// Allow any match during resolution.  Has no effect
        /// on ME/2000 or above, use the other flags instead.
        /// </summary>
        SLR_ANY_MATCH = 0x2,

        /// <summary>
        /// Call the Microsoft Windows Installer.
        /// </summary>
        SLR_INVOKE_MSI = 0x80,

        /// <summary>
        /// Disable distributed link tracking. By default,
        /// distributed link tracking tracks removable media
        /// across multiple devices based on the volume name.
        /// It also uses the UNC path to track remote file
        /// systems whose drive letter has changed. Setting
        /// SLR_NOLINKINFO disables both types of tracking.
        /// </summary>
        SLR_NOLINKINFO = 0x40,

        /// <summary>
        /// Do not display a dialog box if the link cannot be resolved.
        /// When SLR_NO_UI is set, a time-out value that specifies the
        /// maximum amount of time to be spent resolving the link can
        /// be specified in milliseconds. The function returns if the
        /// link cannot be resolved within the time-out duration.
        /// If the timeout is not set, the time-out duration will be
        /// set to the default value of 3,000 milliseconds (3 seconds).
        /// </summary>
        SLR_NO_UI = 0x1,

        /// <summary>
        /// Not documented in SDK.  Assume same as SLR_NO_UI but
        /// intended for applications without a hWnd.
        /// </summary>
        SLR_NO_UI_WITH_MSG_PUMP = 0x101,

        /// <summary>
        /// Do not update the link information.
        /// </summary>
        SLR_NOUPDATE = 0x8,

        /// <summary>
        /// Do not execute the search heuristics.
        /// </summary>
        SLR_NOSEARCH = 0x10,

        /// <summary>
        /// Do not use distributed link tracking.
        /// </summary>
        SLR_NOTRACK = 0x20,

        /// <summary>
        /// If the link object has changed, update its path and list
        /// of identifiers. If SLR_UPDATE is set, you do not need to
        /// call IPersistFile::IsDirty to determine whether or not
        /// the link object has changed.
        /// </summary>
        SLR_UPDATE  = 0x4
    };


    #undef STGM_DIRECT
    #undef STGM_TRANSACTED
    #undef STGM_READ
    #undef STGM_WRITE
    #undef STGM_READWRITE
    #undef STGM_SHARE_DENY_NONE
    #undef STGM_SHARE_DENY_READ
    #undef STGM_SHARE_DENY_WRITE
    #undef STGM_SHARE_EXCLUSIVE
    #undef STGM_PRIORITY
    #undef STGM_DELETEONRELEASE
    #undef STGM_CREATE
    #undef STGM_CONVERT
    #undef STGM_FAILIFTHERE

    public enum class EPersistFileModeFlags : unsigned int
    {
        STGM_DIRECT             = 0x00000000,
        STGM_TRANSACTED         = 0x00010000,

        STGM_READ               = 0x00000000,
        STGM_WRITE              = 0x00000001,
        STGM_READWRITE          = 0x00000002,

        STGM_SHARE_DENY_NONE    = 0x00000040,
        STGM_SHARE_DENY_READ    = 0x00000030,
        STGM_SHARE_DENY_WRITE   = 0x00000020,
        STGM_SHARE_EXCLUSIVE    = 0x00000010,

        STGM_PRIORITY           = 0x00040000,
        STGM_DELETEONRELEASE    = 0x04000000,

        STGM_CREATE             = 0x00001000,
        STGM_CONVERT            = 0x00020000,
        STGM_FAILIFTHERE        = 0x00000000
    };


    // Unmanaged wrapper for IShellLink
    private class RawShellLink
    {
    public:
        RawShellLink();
        ~RawShellLink();

        //
        // IShellLink
        //

        String^ get_Arguments();
        String^ get_Description();
        WORD get_Hotkey();

        // Returns '"<path>",<index>'
        String^ get_IconLocation();
        String^ get_Path(DWORD flags);
        EShowWindowFlags get_ShowCmd();
        String^ get_WorkingDirectory();

        void set_Arguments(String^ value);
        void set_Description(String^ value);
        void set_Hotkey(WORD value);

        // Accepts '"<path>",<index>'
        void set_IconLocation(String^ value);

        void set_Path(String^ value);
        void set_RelativePath(String^ value);
        void set_ShowCmd(EShowWindowFlags value);
        void set_WorkingDirectory(String^ value);

        void Resolve(IntPtr hwnd, DWORD flags);

        //
        // IPersist
        //

        CLSID get_ClassID();

        //
        // IPersistFile
        //

        bool is_Dirty();
        void Load(String^ filename, DWORD mode);
        void Save(String^ filename, bool remember);
        void SaveCompleted(String^ filename);
        String^ get_CurFile();

        //
        // IShellLinkDataList
        //

        void
        AddDataBlock(
            void* data
            );

        void*
        CopyDataBlock(
            DWORD signature
            );

        void
        RemoveDataBlock(
            DWORD signature
            );

        DWORD get_Flags();
        void set_Flags(DWORD flags);

    private:
        IShellLinkW* m_link;
        IShellLinkDataList* m_datalist;
        IPersistFile* m_file;
    };


    // Managed version of EXP_SPECIAL_FOLDER
    public ref struct ExpSpecialFolder
    {
        DWORD idSpecialFolder;
        DWORD cbOffset;
    };


    // Managed version of NT_CONSOLE_PROPS
    public ref struct NtConsoleProps
    {
        WORD wFillAttribute;
        WORD wPopupFillAttribute;
        Point dwScreenBufferSize;
        Point dwWindowSize;
        Point dwWindowOrigin;
        DWORD nFont;
        DWORD nInputBufferSize;
        Point dwFontSize;
        UINT uFontFamily;
        UINT uFontWeight;
        String^ FaceName;
        UINT uCursorSize;
        bool bFullScreen;
        bool bQuickEdit;
        bool bInsertMode;
        bool bAutoPosition;
        UINT uHistoryBufferSize;
        UINT uNumberOfHistoryBuffers;
        bool bHistoryNoDup;
        array<Color>^ ColorTable;

        NtConsoleProps():
            FaceName("")
        {
            ColorTable = gcnew array<Color>
            {
                Color::FromArgb(0x000000),
                Color::FromArgb(0x800000),
                Color::FromArgb(0x008000),
                Color::FromArgb(0x808000),
                Color::FromArgb(0x000080),
                Color::FromArgb(0x800080),
                Color::FromArgb(0x008080),
                Color::FromArgb(0x808080),
                Color::FromArgb(0x000000),
                Color::FromArgb(0xff0000),
                Color::FromArgb(0x00ff00),
                Color::FromArgb(0xffff00),
                Color::FromArgb(0x0000ff),
                Color::FromArgb(0xff00ff),
                Color::FromArgb(0x00ffff),
                Color::FromArgb(0xffffff)
            };
        }
    };


    // Managed wrapper for IShellLink
    public ref class ShellLink
    {
    public:
        ShellLink();
        ~ShellLink();

        //
        // IShellLink pseudo properties
        //

        property String^ Arguments
        {
            String^ get()
            {
                return m_link->get_Arguments();
            }

            void set(String^ value)
            {
                m_link->set_Arguments(value);
            }
        }

        property String^ Description
        {
            String^ get()
            {
                return m_link->get_Description();
            }

            void set(String^ value)
            {
                m_link->set_Description(value);
            }
        }

        property unsigned short Hotkey
        {
            unsigned short get()
            {
                return m_link->get_Hotkey();
            }

            void set(unsigned short value)
            {
                m_link->set_Hotkey(value);
            }
        }

        property String^ IconLocation
        {
            String^ get()
            {
                return m_link->get_IconLocation();
            }

            void set(String^ value)
            {
                m_link->set_IconLocation(value);
            }
        }

        property EShowWindowFlags ShowCmd
        {
            EShowWindowFlags get()
            {
                return m_link->get_ShowCmd();
            }

            void set(EShowWindowFlags value)
            {
                m_link->set_ShowCmd(value);
            }
        }

        property String^ WorkingDirectory
        {
            String^ get()
            {
                return m_link->get_WorkingDirectory();
            }

            void set(String^ value)
            {
                m_link->set_WorkingDirectory(value);
            }
        }

        String^ get_Path(int flags)
        {
            return m_link->get_Path(flags);
        }

        void set_Path(String^ value)
        {
            m_link->set_Path(value);
        }

        void set_RelativePath(String^ value)
        {
            m_link->set_RelativePath(value);
        }

        void Resolve(IntPtr hwnd, unsigned int flags)
        {
            return m_link->Resolve(hwnd, flags);
        }

        //
        // IPersist
        //

        property Guid ClassID
        {
            Guid get()
            {
                CLSID retval = m_link->get_ClassID();
                return Guid(
                    retval.Data1,
                    retval.Data2,
                    retval.Data3,
                    retval.Data4[0],
                    retval.Data4[1],
                    retval.Data4[2],
                    retval.Data4[3],
                    retval.Data4[4],
                    retval.Data4[5],
                    retval.Data4[6],
                    retval.Data4[7]);
            }
        }

        //
        // IPersistFile
        //

        property bool Dirty
        {
            bool get()
            {
                return m_link->is_Dirty();
            }
        }

        void Load(String^ filename, unsigned int mode);

        void Save(String^ filename, bool remember);

        void SaveCompleted(String^ filename)
        {
            m_link->SaveCompleted(filename);
        }

        property String^ CurFile
        {
            String^ get()
            {
                return m_link->get_CurFile();
            }
        }

        //
        // IShellLinkDataList
        //

        property String^ DarwinLink
        {
            String^ get()
            {
                return GetLink(EXP_DARWIN_ID_SIG);
            }

            void set(String^ link)
            {
                SetLink(EXP_DARWIN_ID_SIG, link);
            }
        }

        property String^ TargetLink
        {
            String^ get()
            {
                return GetLink(EXP_SZ_LINK_SIG);
            }

            void set(String^ link)
            {
                SetLink(EXP_SZ_LINK_SIG, link);
            }
        }

        property String^ IconLink
        {
            String^ get()
            {
                return GetLink(EXP_SZ_ICON_SIG);
            }

            void set(String^ link)
            {
                SetLink(EXP_SZ_ICON_SIG, link);
            }
        }

        property ExpSpecialFolder^ SpecialFolder
        {
            ExpSpecialFolder^ get();
            void set(ExpSpecialFolder^ folder);
        }

        property unsigned int FeConsoleProps
        {
            unsigned int get();
            void set(unsigned int folder);
        }

        property NtConsoleProps^ ConsoleProps
        {
            NtConsoleProps^ get();
            void set(NtConsoleProps^ props);
        }

        void
        RemoveDataBlock(
            DWORD signature
            );

        property unsigned int Flags
        {
            unsigned int get()
            {
                return m_link->get_Flags();
            }

            void set(unsigned int flags)
            {
                m_link->set_Flags(flags);
            }
        }

    private:
        String^
        GetLink(
            DWORD signature
            );

        void
        SetLink(
            DWORD signature,
            String^ link
            );

    private:
        RawShellLink* m_link;
    };

}
