#include "stdafx.h"
#using <mscorlib.dll>
#include <Shlobj.h>

#include "ShellLink.h"


namespace ShellLib
{

    RawShellLink::RawShellLink():
        m_link(NULL),
        m_datalist(NULL),
        m_file(NULL)
    {
        HRESULT hr =
            CoCreateInstance(
                CLSID_ShellLink,
                NULL,
                CLSCTX_INPROC_SERVER,
                IID_IShellLinkW,
                (LPVOID *) &m_link);

        if (FAILED(hr))
        {
            throw gcnew COMException(L"", hr);
        }

        hr = m_link->QueryInterface(IID_IPersistFile, (LPVOID *)&m_file);

        if (FAILED(hr))
        {
            m_link->Release();
            m_link = NULL;

            throw gcnew COMException(L"", hr);
        }

        // Note: this call will fail without proxy/stub code for IShellLinkDataList
        hr = m_link->QueryInterface(IID_IShellLinkDataList, (LPVOID *)&m_datalist);

        if (FAILED(hr))
        {
            m_file->Release();
            m_file = NULL;

            m_link->Release();
            m_link = NULL;

            throw gcnew COMException(L"", hr);
        }
    }


    RawShellLink::~RawShellLink()
    {
        if (m_file)
        {
            m_file->Release();
            m_file = NULL;
        }

        if (m_link)
        {
            m_link->Release();
            m_link = NULL;
        }
    }

    //
    // IShellLink
    //

    String^
    RawShellLink::get_Arguments()
    {
        WCHAR buf[INFOTIPSIZE];

        HRESULT hr = m_link->GetArguments(buf, INFOTIPSIZE);

        if (FAILED(hr))
        {
            throw gcnew COMException(L"", hr);
        }

        return gcnew String(buf);
    }

    String^
    RawShellLink::get_Description()
    {
        WCHAR buf[INFOTIPSIZE];

        HRESULT hr = m_link->GetDescription(buf, INFOTIPSIZE);

        if (FAILED(hr))
        {
            throw gcnew COMException(L"", hr);
        }

        return gcnew String(buf);
    }

    WORD
    RawShellLink::get_Hotkey()
    {
        WORD value;

        HRESULT hr = m_link->GetHotkey(&value);

        if (FAILED(hr))
        {
            throw gcnew COMException(L"", hr);
        }

        return value;
    }

    // Returns '"<path>",<index>'
    String^
    RawShellLink::get_IconLocation()
    {
        WCHAR buf[MAX_PATH];
        int index;

        HRESULT hr = m_link->GetIconLocation(buf, MAX_PATH, &index);

        if (FAILED(hr))
        {
            throw gcnew COMException(L"", hr);
        }

        return String::Format(L"\"{0}\",{1}", gcnew String(buf), index);
    }

    String^
    RawShellLink::get_Path(
        DWORD flags
        )
    {
        WCHAR buf[MAX_PATH];
        WIN32_FIND_DATAW data;

        HRESULT hr = m_link->GetPath(buf, MAX_PATH, &data, flags);

        if (FAILED(hr))
        {
            throw gcnew COMException(L"", hr);
        }

        return gcnew String(buf);
    }

    EShowWindowFlags
    RawShellLink::get_ShowCmd()
    {
        int value;

        HRESULT hr = m_link->GetShowCmd(&value);

        if (FAILED(hr))
        {
            throw gcnew COMException(L"", hr);
        }

        return EShowWindowFlags(value);
    }

    String^
    RawShellLink::get_WorkingDirectory()
    {
        WCHAR buf[MAX_PATH];

        HRESULT hr = m_link->GetWorkingDirectory(buf, MAX_PATH);

        if (FAILED(hr))
        {
            throw gcnew COMException(L"", hr);
        }

        return gcnew String(buf);
    }

    void
    RawShellLink::set_Arguments(
        String^ value
        )
    {
        IntPtr valueptr = Marshal::StringToCoTaskMemUni(value);

        HRESULT hr = m_link->SetArguments(static_cast<LPCWSTR>(valueptr.ToPointer()));

        Marshal::FreeCoTaskMem(valueptr);

        if (FAILED(hr))
        {
            throw gcnew COMException(L"", hr);
        }
    }

    void
    RawShellLink::set_Description(
        String^ value
        )
    {
        IntPtr valueptr = Marshal::StringToCoTaskMemUni(value);

        HRESULT hr = m_link->SetDescription(static_cast<LPCWSTR>(valueptr.ToPointer()));

        Marshal::FreeCoTaskMem(valueptr);

        if (FAILED(hr))
        {
            throw gcnew COMException(L"", hr);
        }
    }

    void
    RawShellLink::set_Hotkey(
        WORD value
        )
    {
        HRESULT hr = m_link->SetHotkey(value);

        if (FAILED(hr))
        {
            throw gcnew COMException(L"", hr);
        }
    }

    // Accepts '"<path>",<index>'
    void
    RawShellLink::set_IconLocation(
        String^ value
        )
    {
        // Parse '"<path>",<index>'
        int i = value->LastIndexOf(',');

        if (i == -1)
        {
            throw gcnew ArgumentException();
        }

        String^ path = value->Substring(0, i);
        String^ index = value->Substring(i + 1);

        // Call the wrapped method
        IntPtr pathptr = Marshal::StringToCoTaskMemUni(path);

        HRESULT hr = m_link->SetIconLocation(static_cast<LPCWSTR>(pathptr.ToPointer()), Convert::ToInt32(index));

        Marshal::FreeCoTaskMem(pathptr);

        if (FAILED(hr))
        {
            throw gcnew COMException(L"", hr);
        }
    }

    void
    RawShellLink::set_Path(
        String^ value
        )
    {
        IntPtr valueptr = Marshal::StringToCoTaskMemUni(value);

        HRESULT hr = m_link->SetPath(static_cast<LPCWSTR>(valueptr.ToPointer()));

        Marshal::FreeCoTaskMem(valueptr);

        if (FAILED(hr))
        {
            throw gcnew COMException(L"", hr);
        }
    }

    void
    RawShellLink::set_RelativePath(
        String^ value
        )
    {
        IntPtr valueptr = Marshal::StringToCoTaskMemUni(value);

        HRESULT hr = m_link->SetRelativePath(static_cast<LPCWSTR>(valueptr.ToPointer()), 0);

        Marshal::FreeCoTaskMem(valueptr);

        if (FAILED(hr))
        {
            throw gcnew COMException(L"", hr);
        }
    }

    void
    RawShellLink::set_ShowCmd(
        EShowWindowFlags value
        )
    {
        HRESULT hr = m_link->SetShowCmd(value);

        if (FAILED(hr))
        {
            throw gcnew COMException(L"", hr);
        }
    }

    void
    RawShellLink::set_WorkingDirectory(
        String^ value
        )
    {
        IntPtr valueptr = Marshal::StringToCoTaskMemUni(value);

        HRESULT hr = m_link->SetWorkingDirectory(static_cast<LPCWSTR>(valueptr.ToPointer()));

        Marshal::FreeCoTaskMem(valueptr);

        if (FAILED(hr))
        {
            throw gcnew COMException(L"", hr);
        }
    }

    void
    RawShellLink::Resolve(
        IntPtr hwnd,
        DWORD flags
        )
    {
        HRESULT hr = m_link->Resolve(static_cast<HWND>(hwnd.ToPointer()), flags);

        if (FAILED(hr))
        {
            throw gcnew COMException(L"", hr);
        }
    }

    //
    // IPersist
    //

    CLSID
    RawShellLink::get_ClassID()
    {
        CLSID value;

        HRESULT hr = m_file->GetClassID(&value);

        if (FAILED(hr))
        {
            throw gcnew COMException(L"", hr);
        }

        return value;
    }

    //
    // IPersistFile
    //

    bool
    RawShellLink::is_Dirty()
    {
        HRESULT hr = m_file->IsDirty();
        return (hr == S_OK);
    }

    void
    RawShellLink::Load(
        String^ filename,
        DWORD mode
        )
    {
        IntPtr filenameptr = Marshal::StringToCoTaskMemUni(filename);

        HRESULT hr = m_file->Load(static_cast<LPCWSTR>(filenameptr.ToPointer()), mode);

        Marshal::FreeCoTaskMem(filenameptr);

        if (FAILED(hr))
        {
            throw gcnew COMException(L"", hr);
        }
    }

    void
    RawShellLink::Save(
        String^ filename,
        bool remember
        )
    {
        IntPtr filenameptr = Marshal::StringToCoTaskMemUni(filename);

        HRESULT hr = m_file->Save(static_cast<LPCWSTR>(filenameptr.ToPointer()), remember);

        Marshal::FreeCoTaskMem(filenameptr);

        if (FAILED(hr))
        {
            throw gcnew COMException(L"", hr);
        }
    }

    void
    RawShellLink::SaveCompleted(
        String^ filename
        )
    {
        IntPtr filenameptr = Marshal::StringToCoTaskMemUni(filename);

        HRESULT hr = m_file->SaveCompleted(static_cast<LPCWSTR>(filenameptr.ToPointer()));

        Marshal::FreeCoTaskMem(filenameptr);

        if (FAILED(hr))
        {
            throw gcnew COMException(L"", hr);
        }
    }

    String^
    RawShellLink::get_CurFile()
    {
        // Get a current file name or default prompt

        LPOLESTR value = NULL;

        HRESULT hr = m_file->GetCurFile(&value);

        if (FAILED(hr))
        {
            throw gcnew COMException(L"", hr);
        }

        // Save return value
        String^ retval = gcnew String(value);

        // Free returned value
        LPMALLOC allocator = NULL;
        hr = CoGetMalloc(1, &allocator);

        if (FAILED(hr))
        {
            throw gcnew COMException(L"", hr);
        }

        allocator->Free(value);
        allocator->Release();

        return retval;
    }

    //
    // IShellLinkDataList
    //

    void
    RawShellLink::AddDataBlock(
        void* data
        )
    {
        HRESULT hr = m_datalist->AddDataBlock(data);

        if (FAILED(hr))
        {
            throw gcnew COMException(L"", hr);
        }
    }

    void*
    RawShellLink::CopyDataBlock(
        DWORD signature
        )
    {
        DATABLOCK_HEADER* data = NULL;
        HRESULT hr = m_datalist->CopyDataBlock(signature, (void**)&data);

        return SUCCEEDED(hr) ? data : NULL;
    }

    void
    RawShellLink::RemoveDataBlock(
        DWORD signature
        )
    {
        HRESULT hr = m_datalist->RemoveDataBlock(signature);

        if (FAILED(hr))
        {
            throw gcnew COMException(L"", hr);
        }
    }

    DWORD
    RawShellLink::get_Flags()
    {
        DWORD flags;

        HRESULT hr = m_datalist->GetFlags(&flags);

        if (FAILED(hr))
        {
            throw gcnew COMException(L"", hr);
        }

        return flags;
    }

    void
    RawShellLink::set_Flags(
        DWORD flags
        )
    {
        HRESULT hr = m_datalist->SetFlags(flags);

        if (FAILED(hr))
        {
            throw gcnew COMException(L"", hr);
        }
    }


    //
    // ShellLink
    //

    ShellLink::ShellLink():
        m_link(NULL)
    {
        m_link = new RawShellLink();
    }


    ShellLink::~ShellLink()
    {
        if (m_link)
        {
            delete m_link;
            m_link = NULL;
        }
    }


    void
    ShellLink::Load(
        String^ filename,
        unsigned int mode
        )
    {
        m_link->Load(filename, mode);
    }

    void
    ShellLink::Save(
        String^ filename,
        bool remember
        )
    {
        m_link->Save(filename, remember);
    }


    ExpSpecialFolder^
    ShellLink::SpecialFolder::get()
    {
        ExpSpecialFolder^ retval;

        EXP_SPECIAL_FOLDER* data = (EXP_SPECIAL_FOLDER*)(m_link->CopyDataBlock(EXP_SPECIAL_FOLDER_SIG));

        if (data)
        {
            retval = gcnew ExpSpecialFolder();

            retval->idSpecialFolder = data->idSpecialFolder;
            retval->cbOffset = data->cbOffset;

            LocalFree(data);
        }

        return retval;
    }

    void
    ShellLink::SpecialFolder::set(ExpSpecialFolder^ folder)
    {
        EXP_SPECIAL_FOLDER data;

        data.cbSize = sizeof(data);
        data.dwSignature = EXP_SPECIAL_FOLDER_SIG;
        data.idSpecialFolder = folder->idSpecialFolder;
        data.cbOffset = folder->cbOffset;

        m_link->AddDataBlock(&data);
    }


    unsigned int
    ShellLink::FeConsoleProps::get()
    {
        unsigned int retval = 0;
        NT_FE_CONSOLE_PROPS* data = (NT_FE_CONSOLE_PROPS*)(m_link->CopyDataBlock(NT_FE_CONSOLE_PROPS_SIG));

        if (data)
        {
            retval = data->uCodePage;
            LocalFree(data);
        }

        return retval;
    }

    void
    ShellLink::FeConsoleProps::set(unsigned int codepage)
    {
        NT_FE_CONSOLE_PROPS data;

        data.dbh.cbSize = sizeof(data);
        data.dbh.dwSignature = NT_FE_CONSOLE_PROPS_SIG;
        data.uCodePage = codepage;

        m_link->AddDataBlock(&data);
    }


    NtConsoleProps^
    ShellLink::ConsoleProps::get()
    {
        NtConsoleProps^ retval;

        NT_CONSOLE_PROPS* data = (NT_CONSOLE_PROPS*)(m_link->CopyDataBlock(NT_CONSOLE_PROPS_SIG));

        if (data)
        {
            retval = gcnew NtConsoleProps();

            retval->wFillAttribute          = data->wFillAttribute;
            retval->wPopupFillAttribute     = data->wPopupFillAttribute;
            retval->dwScreenBufferSize      = Point(data->dwScreenBufferSize.X, data->dwScreenBufferSize.Y);
            retval->dwWindowSize            = Point(data->dwWindowSize.X, data->dwWindowSize.Y);
            retval->dwWindowOrigin          = Point(data->dwWindowOrigin.X, data->dwWindowOrigin.Y);
            retval->nFont                   = data->nFont;
            retval->nInputBufferSize        = data->nInputBufferSize;
            retval->dwFontSize              = Point(data->dwFontSize.X, data->dwFontSize.Y);
            retval->uFontFamily             = data->uFontFamily;
            retval->uFontWeight             = data->uFontWeight;
            retval->FaceName                = gcnew String(data->FaceName);
            retval->uCursorSize             = data->uCursorSize;
            retval->bFullScreen             = data->bFullScreen != FALSE;
            retval->bQuickEdit              = data->bQuickEdit != FALSE;
            retval->bInsertMode             = data->bInsertMode != FALSE;
            retval->bAutoPosition           = data->bAutoPosition != FALSE;
            retval->uHistoryBufferSize      = data->uHistoryBufferSize;
            retval->uNumberOfHistoryBuffers = data->uNumberOfHistoryBuffers;
            retval->bHistoryNoDup           = data->bHistoryNoDup != FALSE;

            retval->ColorTable              = gcnew array<Color>(16);
            for (int i = 0; i < 16; ++i)
            {
                retval->ColorTable[i] = Color::FromArgb(data->ColorTable[i]);
            }
        }

        return retval;
    }

    void
    ShellLink::ConsoleProps::set(
        NtConsoleProps^ props
        )
    {
        NT_CONSOLE_PROPS data;

        data.dbh.cbSize                 = sizeof(data);
        data.dbh.dwSignature            = NT_CONSOLE_PROPS_SIG;
        data.wFillAttribute             = props->wFillAttribute;
        data.wPopupFillAttribute        = props->wPopupFillAttribute;
        data.dwScreenBufferSize.X       = static_cast<SHORT>(props->dwScreenBufferSize.X);
        data.dwScreenBufferSize.Y       = static_cast<SHORT>(props->dwScreenBufferSize.Y);
        data.dwWindowSize.X             = static_cast<SHORT>(props->dwWindowSize.X);
        data.dwWindowSize.Y             = static_cast<SHORT>(props->dwWindowSize.Y);
        data.dwWindowOrigin.X           = static_cast<SHORT>(props->dwWindowOrigin.X);
        data.dwWindowOrigin.Y           = static_cast<SHORT>(props->dwWindowOrigin.Y);
        data.nFont                      = props->nFont;
        data.nInputBufferSize           = props->nInputBufferSize;
        data.dwFontSize.X               = static_cast<SHORT>(props->dwFontSize.X);
        data.dwFontSize.Y               = static_cast<SHORT>(props->dwFontSize.Y);
        data.uFontFamily                = props->uFontFamily;
        data.uFontWeight                = props->uFontWeight;

        // Copy unicode string
        IntPtr facenameptr = Marshal::StringToCoTaskMemUni(props->FaceName);
        StringCbCopyW(data.FaceName, sizeof(data.FaceName), static_cast<LPCWSTR>(facenameptr.ToPointer()));
        Marshal::FreeCoTaskMem(facenameptr);

        data.uCursorSize                = props->uCursorSize;
        data.bFullScreen                = props->bFullScreen;
        data.bQuickEdit                 = props->bQuickEdit;
        data.bInsertMode                = props->bInsertMode;
        data.bAutoPosition              = props->bAutoPosition;
        data.uHistoryBufferSize         = props->uHistoryBufferSize;
        data.uNumberOfHistoryBuffers    = props->uNumberOfHistoryBuffers;
        data.bHistoryNoDup              = props->bHistoryNoDup;

        for (int i = 0; i < 16; ++i)
        {
            data.ColorTable[i] = props->ColorTable[i].ToArgb();
        }

        m_link->AddDataBlock(&data);
    }


    void
    ShellLink::RemoveDataBlock(
        DWORD signature
        )
    {
        m_link->RemoveDataBlock(signature);
    }


    String^
    ShellLink::GetLink(
        DWORD signature
        )
    {
        EXP_SZ_LINK* data = (EXP_SZ_LINK*)(m_link->CopyDataBlock(signature));

        if (data)
        {
            String^ retval = gcnew String(data->swzTarget);

            LocalFree(data);

            return retval;
        }
        else
        {
            return nullptr;
        }
    }

    void
    ShellLink::SetLink(
        DWORD signature,
        String^ link
        )
    {
        EXP_SZ_LINK data;
        data.cbSize = sizeof(data);
        data.dwSignature = signature;

        // Copy unicode string
        IntPtr linkptr = Marshal::StringToCoTaskMemUni(link);
        HRESULT hr = StringCbCopyW(data.swzTarget, sizeof(data.swzTarget), static_cast<LPCWSTR>(linkptr.ToPointer()));
        Marshal::FreeCoTaskMem(linkptr);

        if (FAILED(hr))
        {
            throw gcnew COMException(L"", hr);
        }

        // Make the ANSI copy
        int res =
            WideCharToMultiByte(
                CP_ACP,
                0,
                data.swzTarget,
                -1,
                data.szTarget,
                sizeof(data.szTarget),
                NULL,
                NULL);

        if (0 == res)
        {
            data.szTarget[0] = 0;
        }

        m_link->AddDataBlock(&data);
    }

}
