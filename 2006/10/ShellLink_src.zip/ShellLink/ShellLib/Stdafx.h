// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently,
// but are changed infrequently

#pragma once

#using <mscorlib.dll>
#using <system.drawing.dll>

#define _WIN32_DCOM

#include <windows.h>

#pragma warning(push)
#pragma warning(disable: 4793)

#include <strsafe.h>

#pragma warning(pop)


#pragma warning(push)
#pragma warning(disable: 4483)

void __clrcall __identifier(".cctor")()
{}

#pragma warning(pop)
